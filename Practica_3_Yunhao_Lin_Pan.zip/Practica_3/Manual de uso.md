# Práctica 3 de Informática Gráfica

Autor: Yunhao Lin Pan

## Tutorial de uso

Se sitúa en el directorio donde se encuentra el código, se hace a continuación **make** y una vez abierto, por defecto se abre en el objeto articulado, se puede usar las siguientes teclas para cambiar de figura:

* P: modo **pirámide**
* C: modo **cubo**
* O: modo **objeto ply**
* R: modo **cilindro**
* E: modo **esfera**
* N: modo **cono**
* A: modo **objeto articulado**
* M: modo **media esfera**

Para cambiar entres las diferentas vistas disponibles se emleará la siguiente configuración de teclas:

* 1: modo **puntos**
* 2: modo **aristas**
* 3: modo **sólido**
* 4: modo **ajedrez**
* 5: modo **multi_color**

### Movimiento del objeto articulado

* F1: mover hacia abajo el brazo izquierdo
* F2: mover hacia arriba el brazo izquierdo
* F3: mover hacia abajo el brazo derecho
* F4: mover hacia arriba el brazo derecho
* F5: rotar hacia izquierda el torso, junto a los brazos
* F6: rotar hacia derecha el torso, junto a los brazos
* F7: inclinar hacia delantes el torso
* F8: inclinar hacia atrás el torso
* V: rotar la cabeza hacia la derecha
* B: rotar la cabeza hacia la izquierda

## Puntos extras implementados

Se ha implementado como punto extra la parte para cambiar la velocidad de los grados de libertad.
Para hacer uso de ello, se hara uso de las siguientes teclas:

* T: incrementa la velocidad del brazo izq
* Y: decrementa la velocidad del brazo izq
* U: incrementa la velocidad del brazo derecho
* I: decrementa la velocidad del brazo derecho
* S: incrementa la velocidad de rotacion del torso
* D: decrementa la velocidad de rotacion del torso
* F: incrementa la velocidad de inclinación del torso
* G: decrementa la velocidad de inclinación del torso
* H: pausa la animación
* J: resume la animación
* K: resetea la vista al de por defecto
* Z: incrementa la velocidad rotación de la cabeza
* X: decrementa la velocidad de rotación de la cabeza
* S: resetea los grados de libertad
